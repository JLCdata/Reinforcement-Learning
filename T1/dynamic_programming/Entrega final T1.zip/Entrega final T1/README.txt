En esta entrega final hay dos versiones del código, una en formato .ipynb (T1.ipynb) y la otra en formato .py 
(policy_iteration.py y value_iteration.py) con el objetivo de facilitar la lectura según el gusto.

Dentro del archivo utils.py se encuentran las funciones auxiliares para el correcto funcionamiento código.

En los archivos .py se importa el archivo utils.py pero en el archivo T1.ipynb no se importan, esto con el objetivo de debugear y/o revisar las lógicas con mayor facilidad.

Para ejecutar los archivos .py ejecutar en consola dentro del ambiente correspondiente: -> python policy_iteration.py <- y -> python value_iteration.py <-. Con esto se deberian generar 3 imagenes asociadas al reward grid, value function y policy del problema resuelto, y además sus versiones en 
formato .pdf para cada item solicitado (variación de parámetros).

Para ejecutar T1.ipynb, abrir archivo y ejecutar de manera secuencial cada una de las celdas que contiene.
